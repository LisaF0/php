<link rel="stylesheet" href="styleFilm.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/js/all.min.js"></script>
<a href="index.php"><i class="fas fa-arrow-circle-left"></i></a>
<?php
try
{
$bdd = new PDO('mysql:host=localhost;dbname=cinema_dl8_lf;charset=utf8','root','', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
}
catch (Exception $e)
{
    die('Erreur : '. $e->getMessage());
}
$query = $bdd->query("SELECT titre, affiche, annee_sortie, note, synopsis, nom_acteur, prenom_acteur, nom_role
    FROM casting c, film f, acteur a, role r
    WHERE f.id_film = c.id_film
    AND c.id_acteur = a.id_acteur
    AND r.id_role = c.id_role
    AND f.id_film = ".$_GET['id']);

while ($donnees = $query->fetch())
{
    echo 
    "<img src='".
    $donnees['affiche']."'</br>".
    $donnees['titre']."</br></br>
    Année : ".$donnees['annee_sortie']."</br></br>
    Note : ".$donnees['note']."/5</br></br>".
    $donnees['synopsis']."</br></br>
    Casting</br>".$donnees['nom_acteur']." ".$donnees['prenom_acteur']." (".$donnees['nom_role'].")";
    ;
    
}
    




                        
