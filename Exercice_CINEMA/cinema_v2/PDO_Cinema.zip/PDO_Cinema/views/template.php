<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/js/all.min.js"></script>
    <title><?= $titre ?></title>
</head>
<body>
    <h1>Gestion films avec PDO</h1>
    <div>
        <?= $contenu ?>
    </div>
</body>
</html>